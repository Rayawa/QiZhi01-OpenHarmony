#!/bin/bash

#PIN7 UTXD7/GPIO4/gpio7_02
devmem 0x0400140030 4 4   #����ΪUART7

#PIN29 URXD7/GPIO5/gpio7_07
devmem 0x0400140044 4 4   #����ΪUART7

./serial /dev/ttyAMA3
