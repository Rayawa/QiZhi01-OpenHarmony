#!/bin/bash

#PIN36 UTXD2/GPIO16/pad_gpio2_17
devmem 0x0082320040 4 0   #����ΪUART2

#PIN11 URXD2/GPIO17/pad_gpio2_18
devmem 0x0082320044 4 0   #����ΪUART2

./serial /dev/ttyAMA2
