#!/bin/bash

#PIN15 UTXD1/GPIO22/pad_gpio2_15
devmem 0x0082320038 4 0   #����ΪUART1

#PIN16 URXD1/GPIO23/pad_gpio2_16
devmem 0x008232003C 4 0   #����ΪUART1

./serial /dev/ttyAMA1
