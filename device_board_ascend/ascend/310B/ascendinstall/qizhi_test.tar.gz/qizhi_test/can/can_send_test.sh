#!/bin/bash

#PIN31 UCTS2/GPIO6/pad_can_tx2/pad_gpio2_20
devmem 0x008232004C 4 1   #����ΪCAN2

#PIN26 URTS2/GPIO7/pad_can_rx2/pad_gpio2_19
devmem 0x0082320048 4 1   #����ΪCAN2

ip link set can2 down

ip link set can2 type can bitrate 1000000

ip link set can2 up

while (true)
do
    cansend can2 123#1122334455667788
    sleep 1
done