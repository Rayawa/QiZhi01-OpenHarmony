#!/bin/bash

#PIN24 SPI0_CSN/GPIO8/pad_gpio2_26
devmem 0x0082320064 4 0   #����ΪSPI0

#PIN23 SPI0_SCLK/GPIO11/pad_gpio2_25
devmem 0x0082320060 4 0   #����ΪSPI0

#PIN19 SPI0_SDO/GPIO10/pad_gpio2_27
devmem 0x0082320068 4 0   #����ΪSPI0

#PIN21 SPI0_SDI/GPIO9/pad_gpio2_28
devmem 0x008232006C 4 0   #����ΪSPI0

while (true)
do
    ./spidev_test -v -D /dev/spidev0.0
    sleep 1
done
