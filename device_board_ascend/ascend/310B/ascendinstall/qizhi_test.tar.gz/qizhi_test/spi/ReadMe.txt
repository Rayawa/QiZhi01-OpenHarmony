SPI0�ܽŷ���

#PIN24 SPI0_CSN/GPIO8/pad_gpio2_26

#PIN23 SPI0_SCLK/GPIO11/pad_gpio2_25

#PIN19 SPI0_SDO/GPIO10/pad_gpio2_27

#PIN21 SPI0_SDI/GPIO9/pad_gpio2_28


���б���spidev_test.c
gcc spidev_test.c -o spidev_test