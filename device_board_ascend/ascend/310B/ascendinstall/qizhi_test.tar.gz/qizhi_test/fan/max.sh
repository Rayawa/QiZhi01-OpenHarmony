#!/bin/bash

/var/Ascend/install_cache/npu-smi set -t pwm-mode -d 0 > /dev/null
/var/Ascend/install_cache/npu-smi set -t pwm-duty-ratio -d 100 > /dev/null
