#!/bin/bash

i=1
while ((i <= 3))
do
	/var/Ascend/install_cache/npu-smi set -t pwm-mode -d 0 > /dev/null
	/var/Ascend/install_cache/npu-smi set -t pwm-duty-ratio -d 100 > /dev/null
	sleep 4
	/var/Ascend/install_cache/npu-smi set -t pwm-duty-ratio -d 0 > /dev/null
	sleep 2
	let i++
done
/var/Ascend/install_cache/npu-smi set -t pwm-mode -d 1 > /dev/null

