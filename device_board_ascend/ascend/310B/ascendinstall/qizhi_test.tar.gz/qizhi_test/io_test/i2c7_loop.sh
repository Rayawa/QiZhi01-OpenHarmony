#!/bin/bash

#PIN3 SDA7/GPIO2/pad_gpio2_12
devmem 0x008232002C 4 0   #����ΪI2C7

#PIN5 SCL7/GPIO3/pad_gpio2_11
devmem 0x0082320028 4 0   #����ΪI2C7

while (true)
do
    i2cdetect -y 7
    sleep 0.1
done