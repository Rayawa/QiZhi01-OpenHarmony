#!/bin/bash

#PIN32 PWM3/GPIO12/pad_gpio1_01
devmem 0x00C40000D0 4 3   #����ΪGPIO

#PIN8 UTXD0/GPIO14/pad_gpio0_14
#devmem 0x00C40000B4 4 3   #����ΪGPIO

#PIN10 URXD0/GPIO15/pad_gpio0_15
#devmem 0x00C40000B8 4 3   #����ΪGPIO

#PIN18 PWM1_DET/GPIO24/pad_gpio0_25
devmem 0x00C4000100 4 3   #����ΪGPIO

#PIN22 PERST2_N/GPIO25/pad_gpio0_02
devmem 0x00C4000018 4 3   #����ΪGPIO

#PIN37 PERST3_N/GPIO26/pad_gpio0_03
devmem 0x00C400001C 4 3   #����ΪGPIO

#PIN13 PWR_SEQ4/GPIO27/pad_gpio1_06
devmem 0x00C40000F4 4 3   #����ΪGPIO


#PIN24 SPI0_CSN/GPIO8/pad_gpio2_26
devmem 0x0082320064 4 3   #����ΪGPIO

#PIN23 SPI0_SCLK/GPIO11/pad_gpio2_25
devmem 0x0082320060 4 3   #����ΪGPIO

#PIN19 SPI0_SDO/GPIO10/pad_gpio2_27
devmem 0x0082320068 4 3   #����ΪGPIO

#PIN21 SPI0_SDI/GPIO9/pad_gpio2_28
devmem 0x008232006C 4 3   #����ΪGPIO

#PIN31 UCTS2/GPIO6/pad_gpio2_20
devmem 0x008232004C 4 3   #����ΪGPIO

#PIN26 URTS2/GPIO7/pad_gpio2_19
devmem 0x0082320048 4 3   #����ΪGPIO

#PIN3 SDA7/GPIO2/pad_gpio2_12
devmem 0x008232002C 4 3   #����ΪGPIO

#PIN5 SCL7/GPIO3/pad_gpio2_11
devmem 0x0082320028 4 3   #����ΪGPIO

#PIN36 UTXD2/GPIO16/pad_gpio2_17
devmem 0x0082320040 4 3   #����ΪGPIO

#PIN11 URXD2/GPIO17/pad_gpio2_18
devmem 0x0082320044 4 3   #����ΪGPIO

#PIN15 UTXD1/GPIO22/pad_gpio2_15
devmem 0x0082320038 4 3   #����ΪGPIO

#PIN16 URXD1/GPIO23/pad_gpio2_16
devmem 0x008232003C 4 3   #����ΪGPIO


#PIN7 I2S0_MCLK/GPIO4/pad_gpio7_02
devmem 0x0400140030 4 3   #����ΪGPIO

#PIN29 I2S1_MCLK/GPIO5/pad_gpio7_07
devmem 0x0400140044 4 3   #����ΪGPIO

#PIN12 I2S0_BCLK_TX/GPIO18/pad_gpio7_03
devmem 0x0400140034 4 3   #����ΪGPIO

#PIN35 I2S0_WS_TX/GPIO19/pad_gpio7_04
devmem 0x0400140038 4 3   #����ΪGPIO

#PIN40 I2S0_SD_TX/GPIO21/pad_gpio7_05
devmem 0x040014003C 4 3   #����ΪGPIO

#PIN38 I2S0_SD_RX/GPIO20/pad_gpio7_06
devmem 0x0400140040 4 3   #����ΪGPIO


#PIN33 GPIO4_00/GPIO13/pad_gpio4_00
devmem 0x00A01400BC 4 0   #����ΪGPIO

gpios=(2_12 2_11 7_2 2_18 7_3 1_6 2_15 2_16 0_25 2_27 2_28 0_2 2_25 2_26 2_19 7_7 2_20 1_1 4_0 7_4 2_17 0_3 7_6 7_5)

for item in "${gpios[@]}"; do
  IFS='_' read -r a b <<< "$item"
  echo "set_direction $a $b"
  gpio_operate set_direction $a $b 1
done

while (true)
do
	for item in "${gpios[@]}"; do
      IFS='_' read -r a b <<< "$item"
      echo "set_value $a $b"
      gpio_operate set_value $a $b 1
      #sleep 1
    done
    for item in "${gpios[@]}"; do
      IFS='_' read -r a b <<< "$item"
      echo "set_value $a $b"
      gpio_operate set_value $a $b 0
      #sleep 1
    done
done
