#!/bin/bash

while (true)
do
    i2cdetect -y 6
    sleep 0.1
done